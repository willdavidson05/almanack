

 
 
 
 
 
 
 
 
"
#
#
 
S
i
m
p
l
e
 
L
i
s
t
"
,


 
 
 
 
 
 
 
 
"
-
 
I
t
e
m
 
1
"
,


 
 
 
 
 
 
 
 
"
-
 
I
t
e
m
 
2
"
,


 
 
 
 
 
 
 
 
"
-
 
I
t
e
m
 
3
"
,


 
 
 
 
 
 
 
 
"
-
 
I
t
e
m
 
4
"
,


 
 
 
 
 
 
 
 
"
-
 
I
t
e
m
 
5
"
,


 
 
 
 
