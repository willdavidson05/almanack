

 
 
 
 
 
 
 
 
"
#
#
 
S
e
c
t
i
o
n
 
O
n
e
:
 
N
u
m
b
e
r
s
 
a
n
d
 
L
e
t
t
e
r
s
"
,


 
 
 
 
 
 
 
 
"
I
n
 
a
 
g
a
l
a
x
y
 
f
a
r
,
 
f
a
r
 
a
w
a
y
,
 
8
3
7
4
2
 
s
t
a
r
s
h
i
p
s
 
a
s
s
e
m
b
l
e
d
.
 
T
h
e
 
q
u
a
n
t
u
m
 
f
l
u
x
 
a
t
 
9
.
8
1
m
/
s
²
 
w
a
s
 
*
*
a
s
t
o
u
n
d
i
n
g
*
*
!
"
,


 
 
 
 
 
 
 
 
"
-
 
I
t
e
m
 
1
:
 
@
x
&
8
l
K
j
$
1
#
d
7
"
,


 
 
 
 
 
 
 
 
"
-
 
I
t
e
m
 
2
:
 
z
P
9
Q
6
v
^
5
w
T
!
r
C
"
,


 
 
 
 
 
 
 
 
"
-
 
I
t
e
m
 
3
:
 
4
8
3
7
-
1
9
x
y
#
A
!
z
"
,


 
 
 
 
 
 
 
 
"
#
#
 
S
e
c
t
i
o
n
 
T
w
o
:
 
R
a
n
d
o
m
 
S
e
n
t
e
n
c
e
s
"
,


 
 
 
 
 
 
 
 
"
L
o
r
e
m
 
i
p
s
u
m
 
d
o
l
o
r
 
s
i
t
 
a
m
e
t
,
 
4
2
 
n
e
b
u
l
a
s
 
i
n
 
t
h
e
 
c
o
s
m
i
c
 
s
e
a
.
 
Q
u
i
s
q
u
e
 
f
i
n
i
b
u
s
,
 
$
1
0
0
 
b
i
l
l
i
o
n
,
 
a
t
 
i
p
s
u
m
 
t
r
i
s
t
i
q
u
e
:
"
,


 
 
 
 
 
 
 
 
"
1
.
 
`
f
u
n
c
t
i
o
n
(
x
)
 
{
 
r
e
t
u
r
n
 
x
 
*
 
4
2
;
 
}
`
"
,


 
 
 
 
 
 
 
 
"
2
.
 
T
h
e
 
q
u
i
c
k
 
b
r
o
w
n
 
f
o
x
 
j
u
m
p
s
 
o
v
e
r
 
1
3
 
l
a
z
y
 
d
o
g
s
.
"
,


 
 
 
 
 
 
 
 
"
3
.
 
S
u
p
e
r
c
a
l
i
f
r
a
g
i
l
i
s
t
i
c
e
x
p
i
a
l
i
d
o
c
i
o
u
s
 
-
 
a
 
w
o
r
d
 
w
i
t
h
 
m
a
g
i
c
.
"
,


 
 
 
 
 
 
 
 
"
#
#
#
 
S
u
b
s
e
c
t
i
o
n
:
 
M
i
x
e
d
 
C
o
n
t
e
n
t
"
,


 
 
 
 
 
 
 
 
"
`
`
`
p
y
t
h
o
n
"
,


 
 
 
 
 
 
 
 
"
d
e
f
 
e
n
t
r
o
p
y
(
d
a
t
a
)
:
"
,


 
 
 
 
 
 
 
 
"
 
 
 
 
f
r
o
m
 
c
o
l
l
e
c
t
i
o
n
s
 
i
m
p
o
r
t
 
C
o
u
n
t
e
r
"
,


 
 
 
 
 
 
 
 
"
 
 
 
 
i
m
p
o
r
t
 
m
a
t
h
"
,


 
 
 
 
 
 
 
 
"
 
 
 
 
c
o
u
n
t
 
=
 
C
o
u
n
t
e
r
(
d
a
t
a
)
"
,


 
 
 
 
 
 
 
 
"
 
 
 
 
l
e
n
g
t
h
 
=
 
l
e
n
(
d
a
t
a
)
"
,


 
 
 
 
 
 
 
 
"
 
 
 
 
r
e
t
u
r
n
 
-
s
u
m
(
f
r
e
q
u
e
n
c
y
 
/
 
l
e
n
g
t
h
 
*
 
m
a
t
h
.
l
o
g
(
f
r
e
q
u
e
n
c
y
 
/
 
l
e
n
g
t
h
,
 
2
)
 
f
o
r
 
f
r
e
q
u
e
n
c
y
 
i
n
 
c
o
u
n
t
.
v
a
l
u
e
s
(
)
)
"
,


 
 
 
 
 
 
 
 
"
"
,


 
 
 
 
 
 
 
 
'
p
r
i
n
t
(
e
n
t
r
o
p
y
(
"
R
a
n
d
o
m
 
D
a
t
a
 
1
2
3
4
!
"
)
)
'
,


 
 
 
 
 
 
 
 
"
`
`
`
"
,


 
 
 
 
